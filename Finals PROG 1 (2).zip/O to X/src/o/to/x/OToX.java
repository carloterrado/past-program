/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package o.to.x;
import java.util.Scanner;


public class OToX {

    public static String tester(String ans){
        try{
          int convert = Integer.parseInt(ans);
          
          if (convert > 0 && convert <= 10){
              ans = Integer.toString(convert);
              
              return ans;
          }else {
              ans = "-1";
              System.out.println("Invalid input");
              return ans;
          }
        }catch(NumberFormatException e){
            ans = "-1";
            System.out.println("Invalid input");
            return ans;
        }
    }
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        try{
             

         
            char arr[] = {
                'o','o','o','o','o','o','o','o','o','o'
            };
            for(int j = 0; j <= (arr.length-1)/2;j++)
                System.out.print(arr[j]);
            System.out.println();
            
            for(int a = 5; a <= arr.length-1;a++)
                System.out.print(arr[a]);
            System.out.println();
            
            for(int i = 0; i <= arr.length-1;i++){
                while(arr[i] != 'x'){
                    System.out.print("\nEnter no: ");
                   String answer = cin.nextLine();
                    int convert = Integer.parseInt(tester(answer));
                    while(convert <= 0 || convert > 10 ){
                          System.out.print("\nEnter no: ");
                    answer = cin.nextLine();
                     convert = Integer.parseInt(tester(answer));
                    }
                    
                     
                   arr[convert-1]='x';
            for(int z = 0; z <= (arr.length-1)/2;z++)
                System.out.print(arr[z]);
            System.out.println();
            
            for(int a = 5; a <= arr.length-1;a++)
                System.out.print(arr[a]);
            System.out.println();
                   
                }
                

             
            }
                  
         System.out.print("\nThank you!!!\n");

            System.exit(0);
         
        }catch(NumberFormatException e){
            System.out.print(e);
        }
    }
    
}
