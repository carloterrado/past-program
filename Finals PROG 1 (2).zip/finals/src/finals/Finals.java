/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 *
 * @author iamca
 */
public class Finals {
        public static PreparedStatement pstmt = null ;
        public static Statement stmt = null;
         public static Connection con =null; 
        

        
    public static Connection getcon() throws Exception{
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con =DriverManager.getConnection("jdbc:mysql://localhost:3306/reserve?autoReconnect=true&useSSL=false",
                    "root","");
           //System.out.println("connected");
            return con;
        }catch (SQLException e){
            System.out.print(e);
            return null;
        }
    }
    
//   cd Users\iamca\Documents\NetBeansProjects\finals\src\finals
    
    public static void view() throws IOException{
       InputStreamReader r = new InputStreamReader(System.in);
        BufferedReader cin = new BufferedReader(r);
        try{
             stmt = con.createStatement();
ResultSet rs = stmt.executeQuery("SELECT * FROM reserve");
System.out.println("\n\nID\tName\tDate\t\tTime\tAdult\tChildren");
while (rs.next()) {
  System.out.println(rs.getInt("id")+ "\t" 
                    + rs.getString("name")+ "\t"
                    + rs.getString("date")+ "\t"
                    + rs.getString("time")+ "\t  "
                    + rs.getInt("adult")+ "\t  "
                    + rs.getInt("children"));
}
        }catch (SQLException e) {
                System.out.println(e);
                
            }
        System.out.print("\n\n[1]home: "); 
                  String ans = cin.readLine();
                  Integer a = Integer.valueOf(ans);
                  switch(a){
                      case 1: main(null); break;
                      default: view();
                  }
    }
    
    public static void make() throws IOException{
        InputStreamReader r = new InputStreamReader(System.in);
        BufferedReader cin = new BufferedReader(r);
    
        System.out.println("\n\n**Please fill up the following:");
        System.out.print("Name: ");
         String name = cin.readLine();
         
          System.out.print("Date: ");
         String date = cin.readLine(); 
         
         System.out.print("Time: ");
         String time = cin.readLine(); 
         
         System.out.print("No. of adults: ");
         String adult = cin.readLine();
         Integer adults = Integer.valueOf(adult);
         
          System.out.print("No. of children: ");
         String children = cin.readLine();
         Integer childrens = Integer.valueOf(children);
            try{
                 String sql = "INSERT INTO reserve (name,date,time,adult,children) VALUES (?,?,?,?,?)";
            pstmt=con.prepareStatement(sql);
            pstmt.setString(1,name);
            pstmt.setString(2,date);
            pstmt.setString(3,time);
            pstmt.setInt(4,adults);
             pstmt.setInt(5,childrens);
            pstmt.executeUpdate();
            } catch (SQLException e) {
            System.out.println(e);
        }         
                
         System.out.print("\n\n[1]continue [2]home: "); 
                  String ans = cin.readLine();
                  Integer a = Integer.valueOf(ans);
                  switch(a){
                      case 1: make(); break;
                      case 2: main(null); break;
                      default: make();
                  }
         
}
    
    public static void main(String[] args) {
InputStreamReader r = new InputStreamReader(System.in);
        BufferedReader cin = new BufferedReader(r);
        try{
            
        getcon();
        System.out.println("\n\n***System Menu***");
        System.out.println("a. View all Reservations ");
        System.out.println("b. Make Reservation");
        System.out.println("c. Delete Reservation");
        System.out.println("d. Generate Report");
        System.out.println("e. Exit");
        
         System.out.print("Your answer: ");
         
         String ans = cin.readLine();
         switch(ans){
                case "a":
                    view();
                    break;
                case "b":
                    make();
                    break;
               
                default:    
                    main(null);
         }
        }catch(Exception e){
            
        }
    }
    
}
    