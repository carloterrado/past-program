<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Ingredients_model extends CI_Model {
    
    public function create($formArray) {
        $this->db->insert('ingredients', $formArray);
    }

    public function getMenu() {
        $result = $this->db->get('ingredients')->result_array();
        return $result;
    }

    public function getSingleDish($id) {
        $this->db->where('d_id', $id);
        $dish = $this->db->get('ingredients')->row_array();
        return $dish;
    }

    public function update($id, $formArray) {
        $this->db->where('d_id', $id);
        $this->db->update('ingredients', $formArray);
    } 

    public function delete($id) {
        $this->db->where('d_id',$id);
        $this->db->delete('ingredients');
    }

    public function countIng() {
        $query = $this->db->get('ingredients');
        return $query->num_rows();
    }

    public function getIng($id) {
        $this->db->where('d_id', $id);
        $dish = $this->db->get('ingredients')->result_array();
        return $dish;
    }
}
