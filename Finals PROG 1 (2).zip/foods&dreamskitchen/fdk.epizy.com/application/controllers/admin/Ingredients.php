<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Ingredients extends CI_Controller {
    public function __construct(){
        parent::__construct();
       
        $user = $this->session->userdata('user');
       if(empty($user)) {
            $this->session->set_flashdata('msg', 'You need to login first');
            redirect(base_url().'login/index');

        }
        $this->load->helper('url');
    }

    public function index() {

        $this->load->model('Ingredients_model');
        $ingredients = $this->Ingredients_model->getMenu();
        $data['ingredients'] = $ingredients;
        $this->load->view('admin/partials/header');
        $this->load->view('admin/ingredients/list', $data);
        $this->load->view('admin/partials/footer');
    }

    public function create_ingredient(){    

        $this->load->model('Ingredients_model');
        $dish = $this->Ingredients_model->getMenu();
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('name', 'Dish name','trim|required');
        $this->form_validation->set_rules('price', 'Price','trim|required');


        if($this->form_validation->run() == true) {

                $formArray['name'] = $this->input->post('name');          
                $formArray['price'] = $this->input->post('price');
              
                $this->Ingredients_model->create($formArray);
                
                $this->session->set_flashdata('dish_success', 'Ingredient added successfully');
                redirect(base_url(). 'admin/ingredients/index');
       
        } else {
            $data['dish']= $dish;
            $this->load->view('admin/partials/header');
            $this->load->view('admin/ingredients/add_ingredient', $data);
            $this->load->view('admin/partials/footer');
        }
        
    }

    public function edit($id) {
        $this->load->model('Ingredients_model');
        $dish = $this->Ingredients_model->getSingleDish($id);

    
        if(empty($dish)) {

            $this->session->set_flashdata('error', 'Ingredients not found');
            redirect(base_url(). 'admin/ingredients/index');
        }

   
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">','</p>');
        $this->form_validation->set_rules('name', 'Dish name','trim|required');
        $this->form_validation->set_rules('price', 'Price','trim|required');

        if($this->form_validation->run() == true) {

         
                $formArray['name'] = $this->input->post('name');
                $formArray['price'] = $this->input->post('price');
              
                $this->Ingredients_model->update($id, $formArray);
    
                $this->session->set_flashdata('dish_success', 'Ingredients updated successfully');
                redirect(base_url(). 'admin/ingredients/index');
     
        } else {
            $data['dish'] = $dish;
          
            $this->load->view('admin/partials/header');
            $this->load->view('admin/ingredients/edit', $data);
            $this->load->view('admin/partials/footer');

        }

    }
    public function delete($id){

        $this->load->model('Ingredients_model');
        $dish = $this->Ingredients_model->getSingleDish($id);

        if(empty($dish)) {
            $this->session->set_flashdata('error', 'Ingredients not found');
            redirect(base_url().'admin/ingredients');
        }

        

        $this->Ingredients_model->delete($id);

        $this->session->set_flashdata('dish_success', 'Ingredients deleted successfully');
        redirect(base_url().'admin/ingredients/index');

    }
}