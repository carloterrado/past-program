<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function index()
	{
		$this->load->model('Menu_model');
		$dish = $this->Menu_model->getMenu();
		$data['dishesh'] = $dish;
		$this->load->view('front/partials/header');
		$this->load->view('front/home', $data);
		$this->load->view('front/partials/footer');
	}

	public function sendMail() {

		$this->load->library('email');
		$this->load->library('encrypt');
		$this->load->library('form_validation');
        $this->form_validation->set_rules('name','name', 'trim|required');
        $this->form_validation->set_rules('email','email', 'trim|required');
        $this->form_validation->set_rules('subject','subject', 'trim|required');
        $this->form_validation->set_rules('message','message', 'trim|required');

		//SMTP & mail configuration
            $config = array(
    'protocol'  => 'smtp',
    'smtp_host' => 'ssl://smtp.googlemail.com',
    'smtp_port' => 465,
    'smtp_user' => 'scplp03@gmail.com',
    'smtp_pass' => 'Roselyn16!',
    'mailtype'  => 'html',
    'charset'   => 'utf-8'
);

$this->email->initialize($config);
$this->email->set_mailtype("html");
$this->email->set_newline("\r\n");

if($this->form_validation->run() == FALSE) {
			
				$this->session->set_flashdata("msg","mail is not sent, try again.");
			redirect(base_url().'home/index');
			
			
		} else {
//Email content
               $name = $this->input->post('name');
			$emailFrom = $this->input->post('email');
			$subject = $this->input->post('subject');
			$message = $this->input->post('message');
            $recipient = 'scplp03@gmail.com' ;

            $this->email->to($recipient);
            $this->email->from($emailFrom,$name);
            $this->email->subject($subject);
            $this->email->message($message);

//Send email
           $this->email->send();
            $this->session->set_flashdata("msg","mail has been sent successfully");
				redirect(base_url().'home/index');
		}
    }
}