-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2021 at 01:20 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodorderigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `email`, `date`) VALUES
(1, 'admin', 'passpass', 'admin123@gmail.com', '2021-02-26 16:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `dishesh`
--

CREATE TABLE `dishesh` (
  `d_id` int(11) NOT NULL,
  `r_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `about` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dishesh`
--

INSERT INTO `dishesh` (`d_id`, `r_id`, `name`, `about`, `price`, `img`) VALUES
(1, 1, 'Pancit Mix', ' This recipe is a combination of pancit canton and pancit bihon. It has both pork and chicken, pan-fried shrimp added to it, and the combination of different vegetables, which made the ingredients blend to an extremely exquisite taste.', 800, 'pan.png'),
(2, 3, 'Valenciana', 'One of the Filipino dishes with a Spanish origin, prepared with the tasty traditional flavors of malagkit ,coconut milk, chicken, and boiled eggs. This authentic recipe is colorful and festive making it ideal for holidays and special events!', 400, 'valen.png'),
(3, 4, 'Chiffon Cake', 'This moist chiffon cake is simple, delicate and delicious which has a high ratio of eggs to flour and is leavened mainly from the air beaten into the egg whites. The texture falls somewhere between a dense butter cake and a light and airy sponge cake. ', 300, 'chif.png'),
(4, 3, 'Cordon Bleu', 'Rich meal with bold flavors; tender chicken breasts are stuffed with smoky ham and cheese. This variation is roasted till soft and juicy. This recipe is a hit with everyone when served with a simple cream sauce. It has all of the flavor and crunch.', 200, 'cor.png'),
(5, 3, 'Baby Back Ribs', 'With just one glance at a plate of these ribs, you can tell this is a dish that requires a big appetite. Certainly, your inner carnivore will be satisfied!', 200, 'baby.png'),
(6, 2, 'Tori Nori', 'Tori Nori is a mouth-watering fried Japanese dish made from chicken legs, and hotdogs that were all wrapped in a thin sheet of seaweed called Nori. This yummy recipe will burst with flavors when paired with a special sauce.', 200, 'tori.png'),
(24, 2, 'Tempura', 'Tempura is a traditional Japanese meal made up of battered seafood, that are deep fried to achieve the uniquely crispy, non-greasy. The signature crispiness and lightness that tempura is so well-known for. Try our signature tempura now!', 150, 'Menu7.png'),
(25, 3, 'Menudo', 'Also known as ginamay in Cebuano meaning \"chopped into smaller pieces\". It is a scrumptiously rich tomato-based stew of pork, sliced liver. This classic Filipino Menudo meal will astound you with its incredible taste! Consider ordering our Menudo now!', 250, 'Menudo_(2).png'),
(26, 1, 'Pancit Bihon', 'Pancit bihon is a famous Filipino stir-fry consisting of rice noodles combined with sliced pork or chicken and various vegetables. The dish is infused with soy sauce, and it is usually lightly seasoned with calamansi.', 500, 'Bihon.png'),
(27, 1, 'Creamy Carbonara', 'An Italian pasta dish from Rome that is served with a sauce. Its sauce is a creamy combination of eggs, Parmesan cheese, small pieces of bacon and vegetables that coats the pasta with its perfectly silken texture and it somehow leaves you feeling light.', 400, 'Carbonara1.png'),
(28, 4, 'Banana Cake', 'This Banana cake is a type of moist and sweet baked delicacy prepared with mashed bananas that can be served with cream cheese icing, chocolate frosting, or just plain unfrosted. It is nutrient-dense for a delicious approach to be healthy and satisfied!', 200, 'Banana_Bread.png'),
(29, 1, 'Classic Pinoy Style Spaghetti', 'This spaghetti is delicious, weeknight-friendly pasta dish that can be shared with everyone!  The sauce is mainly made with a combination of pork, cheese, mushroom, and sweet tomato sauce. Plus, the cheese totally takes the sauce to the next level.', 400, 'Spagehetti.png'),
(30, 3, 'Morcon', 'Morcon is a Philippine braised beef roulade made with beef flank steak stuffed with hard-boiled eggs, carrots, pickled cucumber, cheese, and various sausages perfect for any occasions.', 300, 'Morcon.png');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `r_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`r_id`, `c_id`, `name`, `img`) VALUES
(1, 0, 'Noodles', 'Untitled_design.png'),
(2, 0, 'Japanese Cuisine', 'jap.png'),
(3, 0, 'Filipino Cuisine', 'fil.png'),
(4, 0, 'Cake|Bread', 'cake.png');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `res_category`
--

INSERT INTO `res_category` (`c_id`, `c_name`) VALUES
(0, 'Italian');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`) VALUES
(35, 'rmaybe', 'Mae', 'Belmonte', 'malingroselyn@gmail.com', '09663360773', '$2y$10$cLd9lSemrF.BUrRxMD.UK.1MYpv9euovQVoq/zYDH0MMfh9ySueIG', 'Blk. 3 Lot 29 Brgy. Gavino Maderan, GMA, Cavite'),
(38, 'Carlo', 'Carlo', 'Terrado', 'iamcarloterrado@gmail.com', '09501311944', '$2y$10$vSdwZUNpob6UN08cRXQKeOC3RImjjXrXAGOdwdV7a3.n.XOLfdBQy', 'Brgy. Granados 7/11'),
(39, 'Chelle_maling', 'Chelle', 'Maling', 'chellemaling@gmail.com', '09663360773', '$2y$10$yTlC34x93wOMSael68tnq.zeBzH40PY1/.rrq7jvGIeDxaKAB0fIS', 'Blk. 3 Lot 29 Brgy. Langgam, San Pedro City, Laguna');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `o_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `d_id` int(11) NOT NULL,
  `d_name` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `price` float NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `success-date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `r_id` int(11) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `d_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_orders`
--

INSERT INTO `user_orders` (`o_id`, `u_id`, `d_id`, `d_name`, `quantity`, `price`, `status`, `date`, `success-date`, `r_id`, `payment`, `area`, `d_date`) VALUES
(48, 38, 4, 'Cordon Bleu', 1, 200, 'closed', '2021-07-05 01:49:17', '2021-07-05 11:51:13', 3, 'Gcash', 'G.M.A', '2021-07-10 15:00:00'),
(50, 35, 6, 'Tori Nori', 1, 200, 'closed', '2021-07-06 12:51:12', '2021-07-06 11:00:25', 2, 'Gcash', 'G.M.A', '2021-07-14 09:53:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `dishesh`
--
ALTER TABLE `dishesh`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `user_orders`
--
ALTER TABLE `user_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dishesh`
--
ALTER TABLE `dishesh`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `user_orders`
--
ALTER TABLE `user_orders`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
